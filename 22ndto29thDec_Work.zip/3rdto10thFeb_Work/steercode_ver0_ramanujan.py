# -*- coding: utf-8 -*-
"""
Created on Thu Feb  6 04:32:39 2020

@author: USER
"""
from bs4 import BeautifulSoup
import pyproj as proj
import numpy as np
import math
from numpy import linalg

latitude = []
longitude = []
def process_coordinate_string(str):
    """
    Take the coordinate string from the KML file, and break it up into [Lat,Lon,Lat,Lon...] for a CSV row
    """
    space_splits = str.split(" ")
    
    # There was a space in between <coordinates>" "-80.123...... hence the [1:]
    
    for spl in space_splits[:-1]:
        comma_split = spl.split(',')
        latitude.append(float(comma_split[1].split()[0]))    # lat
        longitude.append(float(comma_split[0].split()[0]))    # lng



def shortest_distance(x1, y1, a, b, c):    
    d = abs((a * x1 + b * y1 + c)) / (math.sqrt(a * a + b * b))
    return d


with open('theni_farm.kml', 'r') as f:
    
    s = BeautifulSoup(f, 'xml')
    for coords in s.find_all('coordinates'):
        process_coordinate_string(coords.string)
        

'''
cordinates = "77.47490087643872,10.01221321314256,0 77.47520612750324,10.01198661200871,0 77.47493667236044,10.01181125028555,0 77.47517107049974,10.0117822794677,0".split(" ")
for i in cordinates:
    arr = i.split(',')
    latitude.append(float(arr[0]))
    longitude.append(float(arr[1]))
    
print(latitude)
'''

# setup your projections
crs_wgs = proj.Proj(init='epsg:4326') # assuming you're using WGS84 geographic
crs_bng = proj.Proj(init='epsg:27700') # use a locally appropriate projected CRS

# then cast your geographic coordinate pair to the projected system
x, y = proj.transform(crs_wgs, crs_bng, longitude, latitude)

x = np.array(x)
y = np.array(y)

x = (x - x.min()) / (x.max() - x.min())
y = (y - y.min()) / (y.max() - y.min())

x = x*100
y = y*100

origin_x = 4
origin_y = 4
origin_slope = -1

points = []
distance = []
for i in range(0,len(x)):
    points.append(np.asarray((x[i],y[i])))
p = (origin_x , origin_y)
'''
for i in range(0,len(x)-1):
    coef = np.polyfit(points[i],points[i+1],1)
    A = coef[0]
    B = coef[1]
    print(str(points[i])+"   " + str(points[i+1]))
    C = A*points[i][0] + B*points[i][1]
    d = float(shortest_distance(origin_x, origin_y, A, B, C))
    distance.append(d)
   ''' 



for i in range(0,len(x)-1):    
    d = np.linalg.norm((np.cross(points[i+1]-points[i], points[i]-p))/np.linalg.norm(points[i+1]-points[i]))
    distance.append(float(d))

#index = distance.index(min(distance))   
for index in range(0,len(x)-1):
        
    k = ((y[index+1]-y[index])*(origin_x-x[index])-(x[index+1]-x[index])*(origin_y-y[index]))/ ((y[index+1]-y[index])**2 + (x[index+1]-x[index])**2 )
    a = origin_x - k * (y[index+1]-y[index])
    b = origin_y + k * (x[index+1]-x[index])
    print(a,b)

'''
line_slope = (y[index+1]-y[index])/(x[index+1]-x[index])

perpendicular_dist = math.sqrt((origin_x-a)**2 + (origin_y-b)**2)

angle = math.atan(abs((origin_slope + line_slope)/(1 + origin_slope*line_slope)))



slope = []
intercept = []
for i in range(0,len(x)-1):
    tmp = (y[i+1]-y[i])/(x[i+1]-x[i])
    slope.append(tmp)
    tmp = y[i] - (tmp*x[i])
    intercept.append(tmp)
 '''   



