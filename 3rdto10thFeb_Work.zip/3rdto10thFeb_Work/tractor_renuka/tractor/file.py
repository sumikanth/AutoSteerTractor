import turtle

keith = turtle.Turtle()
keith.shape('circle')
wn = turtle.Screen()
keith.shapesize(2,2,2)

def acceleration(steering_angle, time_duration):
    wn.delay(time_duration)
    keith.right(steering_angle)
    #The tractor will move forward for 200px 
    #after turning left or right . 
    #We can input this distance too while calculating the steering angle.
    keith.forward(200)
    wn.delay()

#call the funtion from another file 
#that contains the respective steering angle
#and time duration

#This is sample code
wn.delay(40)
keith.forward(200)
keith.right(-45)
keith.forward(50)
while(keith.pos()!=(0.0,0.0)):
	x=int(input("steering angle"))
	y=int(input("duration"))
	acceleration(x,y)

turtle.done()
