# -*- coding: utf-8 -*-
"""
Created on Thu Feb  6 04:32:39 2020

@author: USER
"""
from bs4 import BeautifulSoup
import pyproj as proj
import numpy as np
import math
from numpy import linalg
import turtle

def acceleration(wn,keith,steering_angle, dist, time_duration,gp):
    keith.radians()
    keith.tilt(steering_angle)
    keith.lt(-steering_angle)
    while(keith.position()[0]!=gp[0] and keith.position()[1]!=gp[1]):
    	keith.forward(10)
    

def autosteer(kmlfile,turtle, wheelbase,velocity,coordsx,coordsy):
	latitude = []
	longitude = []
	L=wheelbase
	vel=velocity
	def process_coordinate_string(str):
	    """
	    Take the coordinate string from the KML file, and break it up into [Lat,Lon,Lat,Lon...] for a CSV row
	    """
	    space_splits = str.split(" ")
	    
	    # There was a space in between <coordinates>" "-80.123...... hence the [1:]
	    
	    for spl in space_splits[:-1]:
		comma_split = spl.split(',')
		latitude.append(float(comma_split[1].split()[0]))    # lat
		longitude.append(float(comma_split[0].split()[0]))    # lng


	def shortest_distance(x1, y1, a, b, c):    
	    d = abs((a * x1 + b * y1 + c)) / (math.sqrt(a * a + b * b))
	    return d


	with open(kmlfile, 'r') as f:  
	    s = BeautifulSoup(f, 'xml')
	    for coords in s.find_all('coordinates'):
		process_coordinate_string(coords.string)
		
	# setup your projections
	crs_wgs = proj.Proj(init='epsg:4326') # assuming you're using WGS84 geographic
	crs_bng = proj.Proj(init='epsg:27700') # use a locally appropriate projected CRS

	# then cast your geographic coordinate pair to the projected system
	x, y = proj.transform(crs_wgs, crs_bng, longitude, latitude)

	x = np.array(x)
	y = np.array(y)

	x = (x - x.min()) / (x.max() - x.min())
	y = (y - y.min()) / (y.max() - y.min())

	x = x*100
	y = y*100

	origin_x = coordsx
	origin_y = coordsy

	points = []
	distance = []
	for i in range(0,len(x)):
	    points.append(np.asarray((x[i],y[i])))

	p = (origin_x , origin_y)

	print(p)
	print("is current coordinates")

	lines=[]
	for i in range(0, len(x)-1):
		lines.append(np.asarray((x[i+1]-x[i],y[i+1]-y[i])))

	for i in range(0,len(x)-1):    
	    d = np.linalg.norm((np.cross(points[i+1]-points[i], points[i]-p))/np.linalg.norm(points[i+1]-points[i]))
	    distance.append(float(d))

	index = distance.index(min(distance))   

	print("index : ",index)

	print("Points: ")
	print(points)

	goalpoint=tuple(np.asarray(0.5*(points[index]+points[index+1])))

	gp=np.asarray(goalpoint)

	print("goalpoint ",gp)

	u=np.asarray(lines[index])
	
	#f=np.asarray(p)
	f=np.asarray([math.cos(turtle.heading()),math.sin(turtle.heading())])

	theta= math.acos((np.dot(u,f))/((np.linalg.norm(u))*(np.linalg.norm(f))))
	
	print("theta",theta*180/math.pi)

	Ld=np.linalg.norm(gp-f)

	print("Length",Ld)

	steerangle=math.atan(2*L*((distance[index]*math.cos(theta))-((Ld**2)-(math.sin(theta)*(distance[index]**2)))**0.5)/Ld)

	radoftrav=2*L*((distance[index]*math.cos(theta))-(Ld**2-math.sin(theta)*distance[index]**2)**0.5)

	print("Radius: ",radoftrav)

	delay=radoftrav/vel
	
	print("Delay: ",delay)

	return steerangle,radoftrav,delay,gp

def plotter(turtle, kmlfile):
    turtle.penup()
    points=kmlcoords(kmlfile)
    for x in points:
        ivy.goto(x[0], x[1])
        turtle.pendown()

def plottwo(turtle):
	turtle.penup()
	steerangle,radoftravel,delay,gp=autosteer(kmf,keith,wb,speed,keith.position()[0],keith.position()[1])
	
	acceleration(wn,keith,steerangle,radoftravel,delay,gp)
        ivy.goto(gp[0], gp[1])
        turtle.pendown()
	
	
def axis(turtle, distance, tick):
    position = turtle.position()
    turtle.pendown()

    for _ in range(0, distance // 2, tick):
        turtle.forward(tick)
        turtle.dot()

    turtle.setposition(position)

    for _ in range(0, distance // 2, tick):
        turtle.backward(tick)
        turtle.dot()


def process_coordinate_string(str):
	   
	    """
	    Take the coordinate string from the KML file, and break it up into [Lat,Lon,Lat,Lon...] for a CSV row
	    """
	    latitude=[]
	    longitude=[]
	    space_splits = str.split(" ")
	    
	    # There was a space in between <coordinates>" "-80.123...... hence the [1:]
	    
	    for spl in space_splits[:-1]:
		comma_split = spl.split(',')
		latitude.append(float(comma_split[1].split()[0]))    # lat
		longitude.append(float(comma_split[0].split()[0]))    # lng
	    return latitude,longitude


def kmlcoords(kmlfile):

	latitude=[]
        longitude=[]
	with open(kmlfile, 'r') as f:
	    
	    s = BeautifulSoup(f, 'xml')
	    for coords in s.find_all('coordinates'):
		latitude,longitude=process_coordinate_string(coords.string)
		
	# setup your projections
	crs_wgs = proj.Proj(init='epsg:4326') # assuming you're using WGS84 geographic
	crs_bng = proj.Proj(init='epsg:27700') # use a locally appropriate projected CRS

	# then cast your geographic coordinate pair to the projected system
	x, y = proj.transform(crs_wgs, crs_bng, longitude, latitude)

	x = np.array(x)
	y = np.array(y)

	x = (x - x.min()) / (x.max() - x.min())
	y = (y - y.min()) / (y.max() - y.min())

	x = x*100
	y = y*100

	points = []
	distance = []
	for i in range(0,len(x)):
	    points.append((x[i],y[i]))
	return points

x=4
y=4

kmf=raw_input("Please enter kml file ")
startx=float(input("Please enter starting x position "))
starty=float(input("Please enter starting y position "))
wb=float(input("Please enter wheelbase in metres "))
speed=float(input("Please enter speed in metres per second "))
img="tractor.gif"
wn = turtle.Screen()
wn.setup(500,500)
wn.register_shape(img)
keith = turtle.Turtle(shape=img)
keith.shapesize(1,1,1)
ivy = turtle.Turtle()
ivy.speed('fastest')
ivy.penup()
axis(ivy, 200, 100)
ivy.penup()
ivy.home()
ivy.setheading(90)
axis(ivy, 200, 100)
plotter(ivy, kmf)
keith.goto(startx,starty)
for i in range(200):
	plottwo(ivy)

wn.exitonclick()






